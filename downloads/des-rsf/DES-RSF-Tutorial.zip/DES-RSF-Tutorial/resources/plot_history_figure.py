"""Rebuild Figure 2 and its numeric samples from the bundled reference run.

Run from the extracted tutorial directory:
    python resources/plot_history_figure.py
The figure uses the same helper as the notebook; no solver run is required.
"""
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import tutorial_tools as tt


def main():
    run = tt.DATA / 'reference/example1_uniform_vw'
    output = tt.DATA / 'figures'
    history = tt.band_history(run)
    tt.configure_plotting()
    fig = tt.plot_history(history, title='Example 1 — supplied uniform-VW reference run')
    for extension in ('png', 'pdf'):
        fig.savefig(output / f'02_full_history.{extension}')
    plt.close(fig)
    elapsed = np.diff(history['time_s'])
    steps = history['step']
    rows = np.column_stack((history['time_s'][:-1] + 0.5 * elapsed,
                            elapsed / np.diff(steps), steps[:-1], steps[1:]))
    np.savetxt(output / '02_time_step_samples.csv', rows, delimiter=',',
               header='time_mid_s,mean_dt_s,step_start,step_end', comments='')
    np.savetxt(output / '02_pseudo_density_samples.csv', tt.pseudo_density_samples(history),
               delimiter=',', header='time_s,monitor_estimated_pseudo_density_kg_m3', comments='')
    print(f'Rebuilt Figure 2 and its CSV data in {output}')


if __name__ == '__main__':
    main()
