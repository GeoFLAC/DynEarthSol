# Preparation

The [tutorial's prerequisites](../Tutorial.html#prerequisites) include build
commands for the compatible 2D HDF5-enabled DES revision and Python setup.
Use Python 3.10 or later. On Windows, run DES and Jupyter inside WSL.

In the extracted tutorial directory:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r resources/requirements.txt
python -m jupyterlab
```

Open a JupyterLab terminal (File → New → Terminal). In that terminal, run
these commands once before Example 1, replacing the placeholder path:

```bash
export DYNEXE="/absolute/path/to/DynEarthSol-tutorial/dynearthsol2d"
export OMP_NUM_THREADS=1
export OMP_DYNAMIC=FALSE
```

Keep that terminal for both examples. Repeat the commands if you open a new
terminal. The executable is not included in the download.

Open `Tutorial.ipynb`. Its first Python cell sets both `RUN` and `SECOND`;
change those paths to your output directories. To use the supplied results,
uncomment the two reference assignments instead. The notebook analyses and plots the selected outputs; it does not run DES.
