# Read decollement.poly: geometry, boundaries and material IDs

Open `resources/models/decollement.poly` beside `example1_uniform_vw.cfg`.
The `.poly` file defines the geometric points, connecting segments and region
labels used to generate a triangular mesh. It is not a list of all mesh nodes
or triangles. The cfg supplies boundary conditions and material properties.

## 1. Points: metres, not kilometres

```text
14 2 0 0
12 50000.0 -4000.0
13 50000.0 -6000.0
```

The header means 14 input points, 2 dimensions, no extra point attributes and
no point boundary-marker column. Each following row is `point_ID x z` in metres.
Points 12 and 13 lie at (50, −4) and (50, −6) km. These IDs are geometric input
IDs, not monitor IDs P0/P1 or guaranteed output-mesh node numbers.

The domain spans x=0–100 km and z=−10–0 km. The band spans z=−6–−4 km;
points 8–11 define its material divisions at x=45 and 55 km. Points 12 and 13
split the horizontal interfaces at x=50 km so that P0 and P1 can match exact
interface vertices. They do not introduce another material region.

## 2. Segments: connect point IDs and label boundaries

```text
18 1
3 3 4 16
7 7 0 32
16 8 9 0
```

There are 18 segments, each with one marker. A row is
`segment_ID first_point_ID second_point_ID boundary_marker`.

| Marker | Meaning here | Boundary condition supplied by cfg |
| --- | --- | --- |
| 1 | Left, x0 | `vbc_x0` |
| 2 | Right, x1 | `vbc_x1` |
| 16 | Bottom, z0 | `vbc_z0=3`, fixed |
| 32 | Top, z1 | `vbc_z1=4`, horizontal loading |
| 0 | Internal segment | Region partition, not an external velocity boundary |

Marker 16 does not mean material 16, and marker 32 does not prescribe a velocity.
For example, segment 16 joins points 8 and 9 and separates left and central band
regions. It does not create a sliding interface or impose a friction jump by itself.

## 3. Holes and region seeds

The `0` after the segments means no holes. The next `5` introduces five regions.

```text
2 50000.0 -5000.0 2 2.0
```

A region row is `region_ID seed_x seed_z material_ID size_constraint`.
The seed is a point inside a region, not a monitor or a new mesh vertex.
The final number controls maximum element size. With DES `meshing_option=91`,
it is normalized using `mesh.resolution`; it is not a distance in kilometres
or an exact edge length. The hosts use 4.0 and the band uses 2.0, allowing finer
elements in the band. Actual edge lengths also depend on geometry and mesh quality.

| Region ID | Location | Material ID |
| --- | --- | --- |
| 0 | Upper host | 4 |
| 1 | Left band, x=0–45 km | 3 |
| 2 | Central band, x=45–55 km | 2 |
| 3 | Right band, x=55–100 km | 1 |
| 4 | Lower host | 0 |

The material list in `[mat]` is indexed by **material ID 0,1,2,3,4**, not by
region-row order or left-to-right order. `num_materials=5` includes both hosts.

## 4. Why three band materials? Where is VS–VW–VS?

The geometry separates a central patch from two flanks. In the current
baseline all three band materials have a=0.003 and b=0.015: they are all VW.
Geometric partitioning alone does not make the flanks VS.

Example 2 assigns VS properties to the flanks and VW properties to the centre,
while retaining the geometry, loading, cohesion, reference velocity, Dc and
resolution:

```ini
direct_a = [0.003, 0.011, 0.011, 0.011, 0.003]
evolution_b = [0.015, 0.001, 0.017, 0.001, 0.015]
```

Materials 3 (left) and 1 (right) use a=0.011, b=0.001, so a−b > 0 (VS).
Material 2 (centre) uses a=0.011, b=0.017, so a−b < 0 (VW). The hosts retain
their baseline list entries and their very large cohesion.

## 5. Why do all three monitor queries use x=50 km?

Both problem-specific cfg files contain `points_x = [50, 50, 50]`. P0 and P1
query 1 m inside the band from its upper and lower faces. The shared
`decollement.poly` includes points 12 and 13 at (50,−4) and (50,−6) km, so the
nearest mesh nodes selected for P0 and P1 lie exactly at x=50 km. These are
sampling vertices only: there is no vertical segment at x=50 km and no new
material region.

P2 also has an input query x of exactly 50 km, at z=−5 km. Because that point is
inside the band rather than on an input segment, the triangular mesh need not
contain a node at exactly (50,−5) km. In a monitor CSV, `query_x` and `query_z`
record the requested position, while `coord_x` and `coord_z` report the nearest
mesh node chosen for coordinate and velocity output. Stress and state are read
from the nearest element. A small difference in P2 `coord_x` therefore does not
mean its input x was different from 50 km.

The along-band displacement plot does not rely on the three monitor points. It
identifies both complete band/host interfaces from material connectivity and
interpolates their horizontal displacement at common reference x. This avoids a
spurious offset when upper and lower interface meshes have different node spacing.

**Exercise:** locate the top segment, identify the seed for material 3, and
predict which cfg list entries must change to make both flanks VS.
