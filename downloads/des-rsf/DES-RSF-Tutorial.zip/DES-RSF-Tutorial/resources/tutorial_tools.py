"""Small, inspectable helpers for the DES RSF workshop notebooks."""
from pathlib import Path
from datetime import datetime
import ast
import configparser
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import time

import h5py
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import font_manager, colors, tri

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "resources"
YEAR = 365.25 * 86400.0


def configure_plotting():
    for path in (DATA / "fonts").glob("texgyreheros-*.otf"):
        font_manager.fontManager.addfont(str(path))
    font = font_manager.findfont("TeX Gyre Heros", fallback_to_default=False)
    plt.rcParams.update({"font.family": "TeX Gyre Heros", "font.size": 11,
                         "axes.spines.top": False, "axes.spines.right": False,
                         "figure.dpi": 120, "savefig.dpi": 180,
                         "pdf.fonttype": 42, "mathtext.fontset": "custom",
                         "mathtext.rm": "TeX Gyre Heros",
                         "mathtext.it": "TeX Gyre Heros:italic",
                         "mathtext.bf": "TeX Gyre Heros:bold"})
    return font


def resolve_executable(value=None):
    value = value or os.environ.get("DYNEXE") or shutil.which("dynearthsol2d")
    if not value:
        raise FileNotFoundError("Set DYNEXE to your compatible HDF5-enabled dynearthsol2d. "
                                "See resources/SETUP.md, or explicitly choose the supplied reference data.")
    path = Path(value).expanduser().resolve()
    if not path.is_file() or not os.access(path, os.X_OK):
        raise FileNotFoundError(f"Executable not found or not executable: {path}")
    return path


def run_model(case="example1_uniform_vw", executable=None, threads=1, timeout=240,
              overrides=None):
    """Run in a fresh temporary directory and retain output for diagnosis.

    Existing runs are never overwritten. The notebook uses the CLI directly.
    """
    cases = ("example1_uniform_vw", "example2_vs_vw_vs")
    if case not in cases:
        raise ValueError(f"Use one of these problem-specific cfg cases: {cases}")
    exe = resolve_executable(executable)
    if int(threads) < 1:
        raise ValueError("threads must be positive")
    work = Path(tempfile.mkdtemp(prefix=f"des-tutorial-{case}-"))
    destination = ROOT / "results" / (datetime.now().strftime("%Y%m%d-%H%M%S") + "-" + work.name)
    (work / "output").mkdir()
    cfg = configparser.ConfigParser(interpolation=None, inline_comment_prefixes=("#", ";"))
    cfg_filename = f"{case}.cfg"
    cfg.read(DATA / "models" / cfg_filename)
    for section, values in (overrides or {}).items():
        if section not in cfg:
            raise ValueError(f"Unknown config section: {section}")
        for key, value in values.items():
            if key not in cfg[section]:
                raise ValueError(f"Unknown config option: {section}.{key}")
            cfg[section][key] = str(value)
    # Keep output paths fixed. Each case may name its own bundled .poly file.
    cfg["sim"]["modelname"] = "output/model"
    cfg["monitor"]["output_prefix"] = "output/monitor"
    poly_name = Path(cfg["mesh"]["poly_filename"]).name
    if poly_name != cfg["mesh"]["poly_filename"]:
        raise ValueError("mesh.poly_filename must name a file in resources/models")
    poly_source = DATA / "models" / poly_name
    if not poly_source.is_file():
        raise FileNotFoundError(f"Missing mesh geometry: {poly_source}")
    cfg["mesh"]["poly_filename"] = poly_name
    with (work / cfg_filename).open("w") as f:
        cfg.write(f)
    shutil.copy2(poly_source, work / poly_name)
    start = time.perf_counter()
    print(f"Running DES, {threads} CPU thread(s). Solver log: {work / 'solver.log'}", flush=True)
    timed_out = False
    with (work / "solver.log").open("w") as log:
        process = subprocess.Popen([str(exe), cfg_filename], cwd=work,
                                   env=dict(os.environ, OMP_NUM_THREADS=str(threads),
                                            OMP_DYNAMIC="FALSE"),
                                   stdout=log, stderr=subprocess.STDOUT)
        try:
            code = process.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            process.kill()
            code = process.wait()
            timed_out = True
        except KeyboardInterrupt:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
            raise RuntimeError(f"Interrupted; partial results retained at {work}")
    elapsed = time.perf_counter() - start
    record = {"case": case, "cfg_filename": cfg_filename,
              "threads": int(threads), "solver_wall_seconds": elapsed,
              "returncode": code, "timed_out": timed_out,
              "executable_sha256": hashlib.sha256(exe.read_bytes()).hexdigest(),
              "configuration": {section: dict(cfg[section]) for section in cfg.sections()}}
    (work / "run.json").write_text(json.dumps(record, indent=2) + "\n")
    shutil.copytree(work, destination)
    if code != 0 or timed_out:
        raise RuntimeError(f"Solver did not finish (timeout={timed_out}, exit={code}). "
                           f"Inspect {destination / 'solver.log'}; original files: {work}")
    # Remove only the unique temporary directory created by this call, after copying.
    if work.parent == Path(tempfile.gettempdir()).resolve() and work.name.startswith("des-tutorial-"):
        shutil.rmtree(work)
    print(f"Completed in {elapsed:.1f} s (solver only). Saved to {destination}", flush=True)
    return destination


def load_monitor(run, point=0):
    path = Path(run) / "output" / f"monitor_point_{point}.csv"
    data = np.atleast_1d(np.genfromtxt(path, delimiter=",", names=True))
    required = ("time_s", "step", "coord_x", "velocity_x", "velocity_z", "stress_2")
    if not all(name in data.dtype.names for name in required):
        raise ValueError(f"Unexpected monitor columns in {path}")
    if len(data) < 2 or not all(np.all(np.isfinite(data[name])) for name in data.dtype.names):
        raise ValueError(f"Incomplete or non-finite monitor data in {path}")
    if np.any(np.diff(data["time_s"]) < 0) or np.any(np.diff(data["step"]) <= 0):
        raise ValueError("Monitor time/step order is invalid")
    return data


def band_history(run):
    upper, lower = load_monitor(run, 0), load_monitor(run, 1)
    centre = load_monitor(run, 2)
    if not np.array_equal(upper["step"], lower["step"]) or not np.array_equal(upper["time_s"], lower["time_s"]):
        raise ValueError("Paired monitor samples are not aligned")
    if not np.array_equal(centre["step"], upper["step"]):
        raise ValueError("Central monitor samples are not aligned")
    displacement = ((upper["coord_x"] - upper["coord_x"][0])
                    - (lower["coord_x"] - lower["coord_x"][0]))
    return {"run": Path(run), "time_s": upper["time_s"], "time_yr": upper["time_s"] / YEAR,
            "step": upper["step"], "relative_vx": upper["velocity_x"] - lower["velocity_x"],
            "relative_displacement": displacement, "shear_stress_mpa": centre["stress_2"] / 1e6,
            "theta_s": centre["state_variable"], "friction": centre["dynamic_friction"],
            "upper": upper, "lower": lower, "centre": centre}


def find_events(history, threshold=1e-3, merge_gap_s=86400.0):
    """Group threshold exceedances separated by <1 model day, including ringing.

    This is a teaching diagnostic, not a physical earthquake definition.
    Durations span first to last exceedance; no recurrence inferred from one event.
    """
    t, speed = history["time_s"], np.abs(history["relative_vx"])
    hits = np.flatnonzero(speed >= threshold)
    if not len(hits):
        return []
    groups = np.split(hits, np.flatnonzero(np.diff(t[hits]) > merge_gap_s) + 1)
    events = []
    for group in groups:
        first, last = int(group[0]), int(group[-1])
        peak = first + int(np.argmax(speed[first:last + 1]))
        quiet = np.flatnonzero((np.arange(len(t)) > last) & (speed < 1e-7))
        end = int(quiet[0]) if len(quiet) else last
        before = max(0, first - 1)
        events.append({"start_index": first, "peak_index": peak, "end_index": last,
                       "quiet_index": end, "start_yr": float(t[first] / YEAR),
                       "peak_time_s": float(t[peak]), "threshold_m_s": threshold,
                       "span_s": float(t[last] - t[first]), "peak_relative_speed": float(speed[peak]),
                       "relative_displacement_m": float(history["relative_displacement"][end] - history["relative_displacement"][before]),
                       "local_shear_stress_drop_mpa": float(history["shear_stress_mpa"][before] - history["shear_stress_mpa"][end]),
                       "relocked": bool(len(quiet))})
    return events


def field_catalog(run):
    rows = []
    for path in sorted((Path(run) / "output").glob("model.save.*.vtkhdf")):
        with h5py.File(path, "r") as f:
            rows.append({"path": path, "time_s": float(f["time_sec"][0]),
                         "step": int(f["steps"][0])})
    if not rows:
        raise FileNotFoundError("No spatial fields: build DES with hdf5=1 or use the reference run.")
    return rows


def read_field(path):
    with h5py.File(path, "r") as f:
        # DES writes these root aliases alongside the ParaView VTKHDF tree.
        result = {name: f[name][:] for name in ("coord0", "coordinate", "connectivity", "velocity",
                                               "plastic strain", "material", "stress")}
        result.update(time_s=float(f["time_sec"][0]), step=int(f["steps"][0]))
    if result["coordinate"].shape[1] != 2 or result["connectivity"].shape[1] != 3:
        raise ValueError("This notebook expects a 2D triangular mesh")
    return result


def select_snapshots(run, history, event_index=0):
    events = find_events(history)
    if event_index >= len(events):
        raise ValueError("Selected event does not exist")
    event = events[event_index]
    catalog = field_catalog(run)
    first = history["time_s"][event["start_index"]]
    quiet = history["time_s"][event["quiet_index"]]
    pre = []
    for row in reversed(catalog):
        if row["time_s"] >= first:
            continue
        with h5py.File(row["path"], "r") as f:
            if np.max(np.linalg.norm(f["velocity"][:], axis=1)) < 1e-7:
                pre = [row]
                break
    post = [r for r in catalog if r["time_s"] >= quiet]
    if not pre or not post:
        raise ValueError("Need both pre-event and relocked field outputs")
    peak = min(catalog, key=lambda r: abs(r["time_s"] - event["peak_time_s"]))
    return [("Before", pre[-1]), ("Rapid slip", peak), ("Relocked", post[0])]


def _interface_profile(field, sample_x_km):
    """Signed upper-minus-lower horizontal displacement across the finite band."""
    conn = field["connectivity"].astype(int)
    material = field["material"].reshape(-1).astype(int)
    nnode = len(field["coord0"])

    def touched(ids):
        selected = np.flatnonzero(np.isin(material, ids))
        flag = np.zeros(nnode, dtype=bool)
        flag[np.unique(conn[selected].ravel())] = True
        return flag

    band = touched((1, 2, 3))
    upper = np.flatnonzero(band & touched((4,)))
    lower = np.flatnonzero(band & touched((0,)))
    if len(upper) < 2 or len(lower) < 2:
        raise ValueError("Could not identify both band/host interfaces")

    def ordered(nodes, label):
        nodes = nodes[np.argsort(field["coord0"][nodes, 0])]
        x = field["coord0"][nodes, 0]
        if np.any(np.diff(x) <= 0):
            raise ValueError(f"{label} interface x coordinates are not unique and increasing")
        return nodes, x

    upper, xu = ordered(upper, "upper")
    lower, xl = ordered(lower, "lower")
    sample_x_m = np.asarray(sample_x_km, dtype=float) * 1000
    if sample_x_m[0] < max(xu[0], xl[0]) or sample_x_m[-1] > min(xu[-1], xl[-1]):
        raise ValueError("Interface nodes do not cover the requested x range")
    ux = field["coordinate"][:, 0] - field["coord0"][:, 0]
    return (np.interp(sample_x_m, xu, ux[upper])
            - np.interp(sample_x_m, xl, ux[lower]))


def interface_displacement_stages(run, history, event_index=0, spacing_km=0.25):
    """Return interseismic and rapid-slip displacement increments along the band.

    The profile is a finite-band kinematic proxy: horizontal displacement of the
    upper band/host interface minus that of the lower interface, interpolated at
    common reference x. It is not an infinitesimal interface discontinuity.
    """
    events = find_events(history)
    if event_index >= len(events):
        raise ValueError("Selected event does not exist")
    event = events[event_index]
    catalog = field_catalog(run)
    start = history["time_s"][event["start_index"]]
    peak_time = event["peak_time_s"]
    regular = [row for row in catalog if row["time_s"] < start - 86400]
    before_event = [row for row in catalog if row["time_s"] < start]
    if len(regular) < 2 or not before_event:
        raise ValueError("Need two quiet fields and one pre-event field")
    inter_start, inter_end = regular[-2], regular[-1]
    event_before = before_event[-1]
    rapid = min(catalog, key=lambda row: abs(row["time_s"] - peak_time))
    if rapid["time_s"] <= event_before["time_s"]:
        raise ValueError("No rapid-slip field follows the pre-event field")

    selected = {"inter_start": inter_start, "inter_end": inter_end,
                "event_before": event_before, "rapid": rapid}
    fields = {key: read_field(row["path"]) for key, row in selected.items()}
    first = fields["inter_start"]
    if not all(np.array_equal(field["connectivity"], first["connectivity"])
               and np.array_equal(field["material"], first["material"])
               for field in fields.values()):
        raise ValueError("Mesh topology/material IDs changed across selected fields")
    x_km = np.arange(0, 100 + 0.5 * spacing_km, spacing_km)
    profiles = {key: _interface_profile(field, x_km) for key, field in fields.items()}
    inter = profiles["inter_end"] - profiles["inter_start"]
    to_rapid = profiles["rapid"] - profiles["event_before"]
    dt_inter = inter_end["time_s"] - inter_start["time_s"]
    dt_to_rapid = rapid["time_s"] - event_before["time_s"]
    creep_projection = inter * dt_to_rapid / dt_inter
    return {"x_km": x_km, "interseismic_increment_m": inter,
            "to_rapid_increment_m": to_rapid,
            "projected_creep_m": creep_projection,
            "excess_over_projected_creep_m": to_rapid - creep_projection,
            "selected": selected, "event": event}


def plot_interface_displacement(run, history, event_index=0):
    """Plot where displacement accumulates between events and during rapid slip."""
    result = interface_displacement_stages(run, history, event_index)
    x = result["x_km"]
    fig, axes = plt.subplots(2, 1, figsize=(10, 6.5), sharex=True, layout="constrained")
    spans = [(0, 45, "#dbe6ee"), (45, 55, "#f5c47e"), (55, 100, "#dbe6ee")]
    for ax in axes:
        for x0, x1, colour in spans:
            ax.axvspan(x0, x1, color=colour, alpha=.55, lw=0)
        ax.axhline(0, color="0.45", lw=.7)
        ax.axvline(45, color="0.4", ls=":", lw=.8)
        ax.axvline(55, color="0.4", ls=":", lw=.8)
        ax.grid(alpha=.15)
        ax.set_ylabel("Band-relative displacement\nincrement (m)")
    axes[0].plot(x, result["interseismic_increment_m"], color="#156b8a", lw=1.8)
    axes[1].plot(x, result["to_rapid_increment_m"], color="#b25324", lw=1.8,
                 label="Observed total increment")
    axes[1].plot(x, result["projected_creep_m"], color="#156b8a", lw=1.2, ls="--",
                 label="Projection of preceding creep rate")
    axes[1].fill_between(x, result["projected_creep_m"], result["to_rapid_increment_m"],
                         color="#b25324", alpha=.16, label="Excess during rapid-slip window")
    rows = result["selected"]
    dt_inter = (rows["inter_end"]["time_s"] - rows["inter_start"]["time_s"]) / YEAR
    dt_to_rapid = (rows["rapid"]["time_s"] - rows["event_before"]["time_s"]) / YEAR
    axes[0].set_title(f"Interseismic increment over {dt_inter:.1f} yr", loc="left")
    axes[1].set_title(f"Last quiet save to rapid-slip snapshot: {dt_to_rapid:.2f} yr", loc="left")
    axes[1].set_xlabel("x (km)")
    for ax in axes:
        ax.text(.225, .95, "VS", transform=ax.transAxes, ha="center", va="top")
        ax.text(.50, .95, "VW", transform=ax.transAxes, ha="center", va="top")
        ax.text(.775, .95, "VS", transform=ax.transAxes, ha="center", va="top")
    axes[1].legend(loc="lower center", ncol=3, frameon=False, fontsize=9)
    fig.suptitle("Paired-interface displacement: creep on the flanks, rupture excess in the centre")
    return fig, result


def pseudo_density_samples(history, cfg_path=None):
    """Estimate pseudo-density using the maximum speed at P0, P1 and P2.

    Monitor speed approximates the solver's global element-mean speed.
    Apply its boundary-speed bound and shear/bulk ceiling using the run cfg.
    Uniform constant material properties are assumed for this workshop.
    No spatial fields or dt-based inversion are used.
    """
    run = Path(history['run'])
    if cfg_path is None:
        configs = list(run.glob('*.cfg'))
        if len(configs) != 1:
            raise ValueError('Specify cfg_path when the run does not contain exactly one cfg')
        cfg_path = configs[0]
    cfg = configparser.ConfigParser(interpolation=None, inline_comment_prefixes=('#', ';'))
    if not cfg.read(cfg_path):
        raise FileNotFoundError(cfg_path)
    if (not cfg.getboolean('control', 'is_quasi_static', fallback=True)
            or not cfg.getboolean('control', 'use_global_velocity_scaling', fallback=False)):
        raise ValueError('Pseudo-density estimation needs quasi-static global velocity scaling')
    moduli = {}
    for key in ('bulk_modulus', 'shear_modulus', 'rho0'):
        values = np.asarray(ast.literal_eval(cfg['mat'][key]), dtype=float)
        if not values.size or not np.all(np.isfinite(values)) or np.any(values <= 0) or not np.all(values == values[0]):
            raise ValueError('Workshop estimate requires uniform positive moduli and density')
        moduli[key] = values[0]
    bulk, shear = moduli['bulk_modulus'], moduli['shear_modulus']
    reference = cfg.get('control', 'mass_scaling_reference_speed', fallback='shear')
    if reference not in ('shear', 'bulk'):
        raise ValueError('Unknown mass_scaling_reference_speed')
    modulus = shear if reference == 'shear' else bulk
    scaling = cfg.getfloat('control', 'inertial_scaling', fallback=1e5)
    if not np.isfinite(scaling) or scaling <= 0:
        raise ValueError('inertial_scaling must be finite and positive')
    boundary_speed = 1e-12  # find_max_vbc floor in the pinned solver (m/s).
    for side in ('x0', 'x1', 'y0', 'y1', 'z0', 'z1', 'n0', 'n1', 'n2', 'n3'):
        mode = cfg.getint('bc', 'vbc_' + side, fallback=0)
        if mode % 2 == 1 or (not side.startswith('n') and mode == 4):
            boundary_speed = max(boundary_speed, abs(cfg.getfloat('bc', 'vbc_val_' + side, fallback=0)))
    # Use absolute vector speed, not the across-band relative horizontal speed.
    monitor_speed = np.maximum.reduce([
        np.hypot(history[name]['velocity_x'], history[name]['velocity_z'])
        for name in ('upper', 'lower', 'centre')])
    estimated_global_speed = np.maximum(monitor_speed, boundary_speed)
    apparent_speed = np.minimum(scaling * estimated_global_speed,
                                np.sqrt(modulus / moduli['rho0']))
    return np.column_stack((history['time_s'], bulk / apparent_speed**2))


def plot_history(history, title="Small decollement"):
    """Plot speed, mean dt, estimated pseudo-density, displacement, stress and state."""
    elapsed = np.diff(history["time_s"])
    steps = np.diff(history["step"])
    if not len(elapsed) or np.any(elapsed <= 0) or np.any(steps <= 0):
        raise ValueError("Mean dt requires increasing monitor times and step numbers")
    # Average over the actual number of solver steps, not the output interval.
    mean_dt = elapsed / steps
    mid_time_yr = (history["time_s"][:-1] + 0.5 * elapsed) / YEAR
    pseudo = pseudo_density_samples(history)
    fig, axes = plt.subplots(6, 1, figsize=(10, 12), sharex=True, layout="constrained")
    t = history["time_yr"]
    axes[0].semilogy(t, np.maximum(np.abs(history["relative_vx"]), 1e-14), color="#156b8a")
    axes[0].axhline(1e-9, color="0.5", ls=":", label="Boundary loading speed")
    axes[0].set_ylabel("Across-band speed\n(m/s)"); axes[0].legend(loc="upper left")
    axes[1].semilogy(mid_time_yr, mean_dt, color="#587b47")
    axes[1].set_ylabel("Mean solver dt\n(s, monitor intervals)")
    axes[2].semilogy(pseudo[:, 0] / YEAR, pseudo[:, 1], color='#946436',
                     label='Monitor-based estimate (P0, P1, P2)')
    axes[2].set_ylabel('Pseudo-density\n(kg/m³)'); axes[2].legend(loc='lower left', fontsize=9)
    axes[3].plot(t, history["relative_displacement"], color="#156b8a"); axes[3].set_ylabel("Across-band\ndisplacement (m)")
    axes[4].plot(t, history["shear_stress_mpa"], color="#b25324"); axes[4].set_ylabel("Local shear stress\n(MPa)")
    axes[5].semilogy(t, history["theta_s"], color="#755589"); axes[5].set_ylabel("Local state θ (s)")
    axes[5].set_xlabel("Model time (yr)"); axes[0].set_title(title, loc="left")
    for ax in axes: ax.grid(alpha=.18)
    return fig


def plot_event(history, event_index=0):
    event = find_events(history)[event_index]
    first, last = event["start_index"], event["end_index"]
    t = history["time_s"] - event["peak_time_s"]
    window = (t >= t[first] - 10) & (t <= t[last] + 10)
    fig, axes = plt.subplots(3, 1, figsize=(10, 7), sharex=True, layout="constrained")
    axes[0].semilogy(t[window], np.maximum(np.abs(history["relative_vx"][window]), 1e-14))
    axes[0].set_ylabel("Across-band speed\n(m/s)")
    axes[1].plot(t[window], history["relative_displacement"][window] - history["relative_displacement"][first])
    axes[1].set_ylabel("Displacement since\nthreshold crossing (m)")
    axes[2].plot(t[window], history["shear_stress_mpa"][window], color="#b25324")
    axes[2].set_ylabel("Local shear stress\n(MPa)"); axes[2].set_xlabel("Time relative to sampled speed peak (s)")
    for ax in axes: ax.axvline(0, color="0.5", ls=":"); ax.grid(alpha=.18)
    axes[0].set_title(f"Event {event_index + 1}: speed, displacement and stress", loc="left")
    return fig


def plot_snapshots(run, history, event_index=0):
    selected = select_snapshots(run, history, event_index)
    fields = [read_field(row["path"]) for _, row in selected]
    base = fields[0]["plastic strain"]
    if not all(np.array_equal(f["connectivity"], fields[0]["connectivity"]) for f in fields):
        raise ValueError("Mesh topology changed; elementwise increments are not valid")
    increments = [f["plastic strain"] - base for f in fields]
    vmax = max(float(np.max(np.abs(v))) for v in increments)
    norm = colors.SymLogNorm(linthresh=max(vmax * .001, 1e-12), vmin=-vmax, vmax=vmax)
    fig, axes = plt.subplots(2, 3, figsize=(13, 5.8), sharex=True, sharey=True, layout="constrained")
    peak_time = find_events(history)[event_index]["peak_time_s"]
    for j, ((label, row), field, increment) in enumerate(zip(selected, fields, increments)):
        xy, conn = field["coordinate"] / 1000, field["connectivity"].astype(int)
        triang = tri.Triangulation(xy[:, 0], xy[:, 1], conn)
        p = axes[0, j].tripcolor(triang, facecolors=increment, cmap="RdBu_r", norm=norm)
        speed = np.linalg.norm(field["velocity"], axis=1)
        v = axes[1, j].tripcolor(triang, np.maximum(speed, 1e-12), shading="gouraud",
                                cmap="magma", norm=colors.LogNorm(1e-10, 2))
        delta = row["time_s"] - peak_time
        when = f"{delta:+.2f} s" if abs(delta) < 86400 else f"{delta / YEAR:+.3f} yr"
        axes[0, j].set_title(f"{label}\n{when} from sampled peak")
        for ax in axes[:, j]:
            ax.set_xlim(0, 100); ax.set_ylim(-10, 0)
            ax.set_aspect(3); ax.set_xlabel("x (km)")
            ax.axhline(-4, color="0.5", lw=.5, ls=":"); ax.axhline(-6, color="0.5", lw=.5, ls=":")
        for point in (0, 1):
            a = load_monitor(run, point)
            i = int(np.argmin(np.abs(a["step"] - row["step"])))
            axes[1, j].plot(a["coord_x"][i] / 1000, a["coord_z"][i] / 1000, "o", ms=3,
                            mfc="none", mec="cyan")
    axes[0, 0].set_ylabel("z (km)"); axes[1, 0].set_ylabel("z (km)")
    from matplotlib.ticker import FormatStrFormatter
    fig.colorbar(p, ax=axes[0, :], label="Plastic-strain change since Before (signed)", shrink=.85,
                 ticks=[-vmax, -.1*vmax, 0, .1*vmax, vmax], format=FormatStrFormatter("%.1e"))
    fig.colorbar(v, ax=axes[1, :], label="Instantaneous nodal speed (m/s)", shrink=.85)
    fig.suptitle("One slip episode in space — vertical exaggeration 3×", x=.05, ha="left")
    return fig, selected


def save_figure(fig, stem):
    directory = ROOT / "results/figures"
    directory.mkdir(parents=True, exist_ok=True)
    for extension in ("png", "pdf"):
        fig.savefig(directory / f"{stem}.{extension}")
    return directory / f"{stem}.png"
