# Rate-and-state friction tutorial

Open **Tutorial.html** to read the tutorial or **Tutorial.ipynb** for the exercises.

1. Follow the setup instructions for a compatible 2D HDF5-enabled DES executable.
2. Install `resources/requirements.txt` and start JupyterLab from this directory.
3. Run each model in a terminal, then analyse and plot its output in the notebook.
4. Answer the observation questions, then expand **Reference result and
   interpretation** to compare with Figures 2–5. Figure 1 stays visible for setup.
5. To analyse the supplied results without a solver, uncomment the two reference
   paths in the notebook's first Python cell.

The notebook performs analysis only. Set `RUN` and `SECOND` in its first Python
cell to select your own outputs or the supplied reference runs.
Sections labeled **supplied data** read the bundled Figure 4/5 arrays regardless
of those selections; they are separate from plotting your own simulation.

| Folder | Contents |
| --- | --- |
| `resources/models/` | Two model inputs, their common geometry and optional dense-output variants |
| `resources/reference/` | Reference monitor histories and selected spatial fields |
| `resources/figures/` | Five PNG/PDF figures, an animation and their numerical data |

The five numbered figures show the reference calculations. Notebook plotting
cells draw additional figures from your selected runs: monitor histories,
a selected event, monitor-interval mean solver time steps, monitor-based
pseudo-density estimates, spatial snapshots and VS/VW
interface displacement. Figure-data cells explicitly identify supplied data.
Python plotting is provided; the exercises ask you to interpret and compare it.
The full-history plot has six panels. Rebuild its supplied Figure 2 and CSV
data with `python resources/plot_history_figure.py`; the other supplied figures
remain unchanged. Pseudo-density uses the largest vector speed at P0/P1/P2
and the run's cfg to approximate global velocity scaling. No spatial fields
are needed for the full-history plot; the density estimate is approximate.
Figure 4 shows the first VS–VW–VS event; Figure 5 follows loading through its
second event. The basic workshop cfg saves fewer spatial fields than the
figure-generation cfgs, so the plotted times and detail may differ.

To export a generated figure as PNG and PDF, use `tt.save_figure` as illustrated
in the notebook. Exports go under `results/figures/`.

See `resources/SETUP.md` for preparation and `resources/POLY_GUIDE.md` for the
mesh format. Save new calculations in separate directories under `results/`.
